# Script to add threonine codons to the sequence

def Thr(i,a,opt):
    if a > 16 and a < 64:
        opt.append('ACC')
    elif a < 17:
        opt.append('ACT')
    elif a > 63 and a < 77:
        opt.append('ACA')
    else:
        opt.append('ACG')
    return opt

def Thrz(i,a,opt):
    if a > 26 and a < 56:
        opt.append('ACC')
    elif a < 27:
        opt.append('ACT')
    elif a > 55 and a < 88:
        opt.append('ACA')
    else:
        opt.append('ACG')
    return opt
