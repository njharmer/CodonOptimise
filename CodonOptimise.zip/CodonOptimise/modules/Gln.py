# Script to add glutamine codons to the sequence

def Gln(i,a,opt):
    if a < 31 or i < 31:
        opt.append('CAA')
    else:
        opt.append('CAG')
    return opt

def Glnz(i,a,opt):
    if a > 26 or i < 21:
        opt.append('CAG')
    else:
        opt.append('CAA')
    return opt
