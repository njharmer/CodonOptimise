# Script to add tyrosine codons to the sequence

def Tyr(i,a,opt):
    if i < 31 or a < 54:
        opt.append('TAT')
    else:
        opt.append('TAC')
    return opt

def Tyrz(i,a,opt):
    if a < 44:
        opt.append('TAT')
    else:
        opt.append('TAC')
    return opt
