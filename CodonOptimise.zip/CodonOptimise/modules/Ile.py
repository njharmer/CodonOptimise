# Script to add isoleucine codons to the sequence

def Ile(i,a,opt):
    if i < 31:
        if a < 82:
            opt.append('ATT')
        else:
            opt.append('ATC')
    else:
        if a < 59:
            opt.append('ATT')
        elif a > 58 and a < 93:
            opt.append('ATC')
        else:
            opt.append('ATA')
    return opt

def Ilez(i,a,opt):
    if i < 21:
        if a < 41:
            opt.append('ATT')
        else:
            opt.append('ATC')
    else:
        if a < 35:
            opt.append('ATT')
        elif a > 34 and a < 85:
            opt.append('ATC')
        else:
            opt.append('ATA')
    return opt
