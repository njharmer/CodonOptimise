# Script to add asparagine codons to the sequence

def Asn(i,a,opt):
    if a < 48:
        opt.append('AAT')
    else:
        opt.append('AAC')
    return opt

def Asnz(i,a,opt):
    if a < 41:
        opt.append('AAT')
    else:
        opt.append('AAC')
    return opt
