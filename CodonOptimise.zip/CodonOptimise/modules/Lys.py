# Script to add lysine codons to the sequence

def Lys(i,a,opt):
    if i < 31 or a < 74:
        opt.append('AAA')
    else:
        opt.append('AAG')
    return opt

def Lysz(i,a,opt):
    if a < 50:
        opt.append('AAA')
    else:
        opt.append('AAG')
    return opt
