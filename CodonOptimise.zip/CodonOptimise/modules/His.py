# Script to add histidine codons to the sequence

def His(i,a,opt):
    if i < 31 or a < 55:
        opt.append('CAT')
    else:
        opt.append('CAC')
    return opt

def Hisz(i,a,opt):
    if a < 43:
        opt.append('CAT')
    else:
        opt.append('CAC')
    return opt
