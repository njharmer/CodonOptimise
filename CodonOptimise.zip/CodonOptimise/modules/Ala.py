# Script to add alanine codons to the sequence

def Ala(i,a,opt):
    if i < 31:
        opt.append('GCA')
    else:
        if a < 11:
            opt.append('GCT')
        elif a > 10 and a < 42:
            opt.append('GCC')
        elif a > 41 and a < 63:
            opt.append('GCA')
        else:
            opt.append('GCG')
    return opt


def Alaz(i,a,opt):
    if i < 21:
        if a < 53:
            opt.append('GCT')
        else:
            opt.append('GCC')
    else:
        if a < 33:
            opt.append('GCT')
        elif a > 32 and a < 63:
            opt.append('GCC')
        elif a > 62 and a < 88:
            opt.append('GCA')
        else:
            opt.append('GCG')
    return opt
