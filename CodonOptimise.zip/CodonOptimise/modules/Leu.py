# Script to add leucine codons to the sequence

def Leu(i,a,opt):
    if i < 31:
        if a < 39:
            opt.append('CTG')
        else:
           opt.append('TTA') 
    else:
        if a < 15:
            opt.append('TTA')
        elif a > 14 and a < 27:
            opt.append('TTG')
        elif a > 26 and a < 39:
            opt.append('CTT')
        elif a > 38 and a < 49:
            opt.append('CTC')
        elif a > 48 and a < 54:
            opt.append('CTA')
        else:
            opt.append('CTG')
    return opt


def Leuz(i,a,opt):
    if i < 21:
        opt.append('CTG') 
    else:
        if a < 8:
            opt.append('TTA')
        elif a > 7 and a < 21:
            opt.append('TTG')
        elif a > 20 and a < 35:
            opt.append('CTT')
        elif a > 34 and a < 53:
            opt.append('CTC')
        elif a > 52 and a < 60:
            opt.append('CTA')
        else:
            opt.append('CTG')
    return opt
