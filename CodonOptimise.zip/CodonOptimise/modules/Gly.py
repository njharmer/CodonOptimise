# Script to add glycine codons to the sequence

def Gly(i,a,opt):
    if i < 31:
        if a < 81:
            opt.append('GGT')
        else:
            opt.append('GGC')
    else:
        if a < 30:
            opt.append('GGT')
        elif a > 31 and a < 76:
            opt.append('GGC')
        elif a > 75 and a < 89:
            opt.append('GGA')
        else:
            opt.append('GGG')
    return opt

def Glyz(i,a,opt):
    if i < 21:
        if a < 41:
            opt.append('GGC')
        else:
            opt.append('GGA')
    else:
        if a < 23:
            opt.append('GGT')
        elif a > 22 and a < 51:
            opt.append('GGC')
        elif a > 50 and a < 85:
            opt.append('GGA')
        else:
            opt.append('GGG')
    return opt
