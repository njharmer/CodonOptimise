# Script to add glutamate codons to the sequence

def Glu(i,a,opt):
    if i < 31 or a < 71:
        opt.append('GAA')
    else:
        opt.append('GAG')
    return opt

def Gluz(i,a,opt):
    if i < 21 or a > 36:
        opt.append('GAG')
    else:
        opt.append('GAA')
    return opt
