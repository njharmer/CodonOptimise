# Script to add serine codons to the sequence

def Ser(i,a,opt):
    if a < 12:
        opt.append('TCT')
    elif a > 11 and a < 23:
        opt.append('TCC')
    elif a > 22 and a < 38:
        opt.append('TCA')
    elif a > 37 and a < 54:
        opt.append('TCG')
    elif a > 53 and a < 68:
        opt.append('AGT')
    else:
        opt.append('AGC')
    return opt

def Serz(i,a,opt):
    if a < 21:
        opt.append('TCT')
    elif a > 20 and a < 39:
        opt.append('TCC')
    elif a > 38 and a < 55:
        opt.append('TCA')
    elif a > 54 and a < 62:
        opt.append('TCG')
    elif a > 61 and a < 78:
        opt.append('AGT')
    else:
        opt.append('AGC')
    return opt
