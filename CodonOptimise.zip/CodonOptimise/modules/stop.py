# Script to add stop codons to the sequence

def stop(i,a,opt):
    if a < 65:
        opt.append('TAA')
    else:
        opt.append('TGA')
    return opt

def stopz(i,a,opt):
    if a < 37:
        opt.append('TAA')
    elif a > 36 and a < 55:
        opt.append('TAG')
    else:
        opt.append('TGA')
    return opt
