# Script to simulate the C-squared function for a given number of
# degrees of freedom.
# The script will generate 1,000 sets of random samples; and return the values
# of C-squared for each of these 1,000 sets.

import numpy

def Csq(n,bn,dist):
    # set up a list of times the numbers fit into the bin
    C2=[]
    sz = 0
    for i in bn:
        C2.append(0)
        sz += 1

    # set a loop to calculate 1,000 random samples
    for j in range(1000):
        # generate a sample set of n samples
        a = numpy.random.normal(0,1,n)
        # calculate the mean of the set
        m = numpy.mean(a)
        # set up a loop to calculate c-squared
        c = 0
        for k in range(n):
            c += ((m-a[k])**2)
        # multiply the number by 10 and round down - tells you which bin
        # to add one to
        b = int(round(c*10/(n-1)))
        # Add one to that bin
        if b<sz:
            C2[b] += 1
        else:
            C2[0] += 0

    dist.append(C2)
    return dist
        
            
            
            
            
            
        
