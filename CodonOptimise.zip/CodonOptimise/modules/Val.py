# Script to add valine codons to the sequence

def Val(i,a,opt):
    if i < 31:
        if a < 60:
            opt.append('GTT')
        else:
            opt.append('GTA')
    elif a < 26:
        opt.append('GTT')
    elif a > 25 and a < 44:
        opt.append('GTC')
    elif a > 43 and a < 61:
        opt.append('GTA')
    else:
        opt.append('GTG')
    return opt

def Valz(i,a,opt):
    if i < 21 or a > 56:
        opt.append('GTG')
    elif a < 23:
        opt.append('GTT')
    elif a > 22 and a < 46:
        opt.append('GTC')
    else:
        opt.append('GTA')
    return opt
