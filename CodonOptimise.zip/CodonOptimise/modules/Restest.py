# Test for restriction sites and remove the last two codons if present

def Restest(opt,res):
    # Join up the codons into a single sequence        
    optimised = ''.join(opt)

    # Test for restriction sites
    site = 'F'
    for r in res:
        f = optimised.find(r)
        if f > 1:
            print('restriction site '+ r + ' found at position '+ str(f))
            site = 'T'
            del opt[-1]
            del opt[-1]
            break

    return site
     
