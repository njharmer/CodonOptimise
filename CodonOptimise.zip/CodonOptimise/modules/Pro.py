# Script to add proline codons to the sequence

def Pro(i,a,opt):
    if a > 44 or i < 21:
        opt.append('CCG')
    elif a < 18:
        opt.append('CCT')
    elif a > 17 and a < 31:
        opt.append('CCC')
    else:
        opt.append('CCA')
    return opt

def Proz(i,a,opt):
    if i < 21:
        if a < 53:
            opt.append('CCT')
        else:
            opt.append('CCA')
    else:
        if a < 32:
            opt.append('CCT')
        elif a > 31 and a < 56:
            opt.append('CCC')
        elif a > 55 and a < 86:
            opt.append('CCA')
        else:
            opt.append('CCG')
    return opt
