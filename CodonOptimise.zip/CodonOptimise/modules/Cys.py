# Script to add cysteine codons to the sequence

def Cys(i,a,opt):
    if i < 31 or a < 43:
        opt.append('TGT')
    else:
        opt.append('TGC')
    return opt

def Cysz(i,a,opt):
    if a < 51:
        opt.append('TGT')
    else:
        opt.append('TGC')
    return opt
