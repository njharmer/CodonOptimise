# Script to add phenylalanine codons to the sequence

def Phe(i,a,opt):
    if i < 31 or a < 57:
        opt.append('TTT')
    else:
        opt.append('TTC')
    return opt

def Phez(i,a,opt):
    if a < 48:
        opt.append('TTT')
    else:
        opt.append('TTC')
    return opt
