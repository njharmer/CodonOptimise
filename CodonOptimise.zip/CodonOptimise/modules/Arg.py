# Script to add arginine codons to the sequence

def Arg(i,a,opt):
    if i < 31:
        if a < 81:
            opt.append('CGT')
        else:
            opt.append('CGC')
    else:
        if a < 37:
            opt.append('CGT')
        elif a > 36 and a < 81:
            opt.append('CGC')
        elif a > 80 and a < 88:
            opt.append('CGA')
        elif a > 87 and a < 95:
            opt.append('CGG')
        elif a > 94 and a < 97:
            opt.append('AGA')
        else:
            opt.append('AGG')
    return opt

def Argz(i,a,opt):
    if i < 21:
        if a < 40:
            opt.append('AGA')
        elif a > 39 and a < 70:
            opt.append('AGG')
        else:
            opt.append('CGC')
    else:
        if a < 14:
            opt.append('CGT')
        elif a > 13 and a < 32:
            opt.append('CGC')
        elif a > 31 and a < 44:
            opt.append('CGA')
        elif a > 43 and a < 56:
            opt.append('CGG')
        elif a > 55 and a < 82:
            opt.append('AGA')
        else:
            opt.append('AGG')
    return opt
