# Script to add aspartate codons to the sequence

def Asp(i,a,opt):
    if i < 31 or a < 65:
        opt.append('GAT')
    else:
        opt.append('GAC')
    return opt

def Aspz(i,a,opt):
    if a < 48:
        opt.append('GAT')
    else:
        opt.append('GAC')
    return opt
